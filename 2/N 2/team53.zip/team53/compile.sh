#!/bin/sh

g++ -o run.out graph_partition.cpp main.cpp -std=c++11 -O3