#!/bin/sh

./run.out $3 < $1 > $2