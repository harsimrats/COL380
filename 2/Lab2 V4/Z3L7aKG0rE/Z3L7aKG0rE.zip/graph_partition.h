#ifndef GP_H
#define GP_H

#include <vector>
#include <utility>
#include <tuple>
#include <unordered_map>

using namespace std;

typedef vector<vector<int> >graph;

vector<int> graph_divide_K(graph&, int, int);

#endif